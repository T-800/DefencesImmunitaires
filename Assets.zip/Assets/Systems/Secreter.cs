﻿using UnityEngine;
using System.Collections;

public class Secreter : MonoBehaviour {
	public string type;
	public float reloadTime = 3f;
	public float reloadProgress = 0f;
	public int NombreMaxSecretion = 10;
	public int NombreActuelle; 
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
