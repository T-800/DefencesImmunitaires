﻿using UnityEngine;

public class Agglutinué : MonoBehaviour {

}