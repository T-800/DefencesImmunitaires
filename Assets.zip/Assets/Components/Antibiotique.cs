﻿using UnityEngine;

public class Antibiotique : MonoBehaviour {
	public int tempseffet = 90;
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
}