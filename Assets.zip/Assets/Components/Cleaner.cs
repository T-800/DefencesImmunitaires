﻿using UnityEngine;

public class Cleaner : MonoBehaviour {
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
}