﻿using UnityEngine;

public class OuvrirFermer : MonoBehaviour {
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
}