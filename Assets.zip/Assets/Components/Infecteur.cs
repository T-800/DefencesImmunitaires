﻿using UnityEngine;

public class Infecteur : MonoBehaviour {
	
	public bool hasInfect;
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
}