﻿using UnityEngine;

public class StreamMove : MonoBehaviour {
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
	public float vitesse = 1f;
}