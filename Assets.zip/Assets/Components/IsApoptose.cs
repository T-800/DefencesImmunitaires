﻿using UnityEngine;

public class IsApoptose : MonoBehaviour {
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
}