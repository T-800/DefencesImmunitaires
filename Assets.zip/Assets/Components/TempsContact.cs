﻿using UnityEngine;

public class TempsContact : MonoBehaviour {
	// Advice: FYFY component aims to contain only public members (according to Entity-Component-System paradigm).
	public int temp = 12 ;
}